package com.example.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=(Button) findViewById(R.id.button);
        button.setOnClickListener(

                new Button.OnClickListener(){

                    public void onClick(View v){

                        TextView textv=(TextView) findViewById(R.id.textv);
                        textv.setText(genString());

                    }
                }

        );
        button.setOnLongClickListener(

                new Button.OnLongClickListener(){

                    public boolean onLongClick(View v){

                        TextView textv=(TextView) findViewById(R.id.textv);
                        textv.setText("Hola!");
                        return true;

                    }
                }
        );

    }

    private String genString(){

        String[] myStrings = { "I have a package I have to sign for.", "Omg, I totally forgot we had plans.", "I have a migraine.","I have terrible diarrhea.","I’m too upset about the state of the country to go out into the world.","I have really bad cramps.","I have the flu.","I had an allergic reaction","I lost my glasses","My pet is sick","I am comprehending our place in the universe","I have a cold(cough cough)" };
        int x = (int)(Math.random()*((11)+1))+0;
        return (myStrings[x]);
        




    }
}


